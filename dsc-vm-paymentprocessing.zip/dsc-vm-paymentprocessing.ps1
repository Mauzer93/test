Configuration DeployPaymentProcessingVM
{
  Param (
    [Parameter(Mandatory=$true)][string] $nodeName)

  Import-DscResource -ModuleName PSDesiredStateConfiguration

  Node $nodeName
  {
    WindowsFeature TelnetClient 
    {      
      Name = 'Telnet-Client'
      Ensure = 'Present'
    }
		
    WindowsFeature WebServerRole
    {
      Name = "Web-Server"
      Ensure = "Present"
    }

    WindowsFeature WebCGI
    {
      Name = "Web-CGI"
      Ensure = "Present"
      DependsOn = "[WindowsFeature]WebServerRole"
    }

    WindowsFeature WebISAPIExt
    {
      Name = "Web-ISAPI-Ext"
      Ensure = "Present"
      DependsOn = "[WindowsFeature]WebServerRole"
    }

    WindowsFeature CompatibilityModeIis6{
        Name = "Web-Mgmt-Compat"
        Ensure = "Present"        
        DependsOn = "[WindowsFeature]WebServerRole"
    }

    WindowsFeature WindowsAuthentication{
        Name = "Web-Windows-Auth"
        Ensure = "Present"        
        DependsOn = "[WindowsFeature]WebServerRole"
    }
  }
}